
jQuery(document).ready(function(){
     //Boton Para abrir el menú de busqueda.
     $("#ButtonSearch").on("click",function()
     {
        $("#aside").slideToggle();
        if($(this).css("color") == "rgb(211, 211, 211)")
        {
             $(this).css({"background-color":"lightgray","color":"#6495ED"});
        }
        else
        {

             $(this).css({"background-color":"#6495ED","color":"lightgray"});
        }
     });

});
$( function() {
   $( "#slider" ).slider({
     range: "min",
     value: 300,
     min: 0,
     max: 1570,
     slide: function( event, ui ) {
       $( "#precio" ).val(ui.value + "€");
     }
   });
   $( "#precio" ).val($( "#slider" ).slider( "value" ) + "€" );
 } );
